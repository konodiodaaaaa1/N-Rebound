import streamlit as st
import pandas as pd
import requests
import os
import subprocess
import sys
import time
import akshare as ak
import plotly.graph_objects as go
from datetime import datetime, timedelta

# ==========================================
# 📍 路径防走丢补丁
# ==========================================
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# ==========================================
# 🛡️ 网络配置
# ==========================================
PROXY_PORT = "7890"
os.environ["http_proxy"] = f"http://127.0.0.1:{PROXY_PORT}"
os.environ["https_proxy"] = f"http://127.0.0.1:{PROXY_PORT}"

st.set_page_config(page_title="N-Rebound 指挥中心", layout="wide", page_icon="🦅")

st.markdown("""
<style>
    .stButton>button {width: 100%; font-weight: bold; border-radius: 8px;}
</style>
""", unsafe_allow_html=True)


# ==========================================
# 🛠️ 后端调度区
# ==========================================

def run_screener():
    """调用收盘选股脚本"""
    cmd = [sys.executable, "night_screener.py"]
    with st.spinner("⏳ 正在执行严选策略..."):
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, encoding='gbk', errors='replace')
            if result.returncode == 0:
                st.success("✅ 选股完成！")
                with st.expander("查看运行日志"):
                    st.code(result.stdout)
                return True
            else:
                st.error("❌ 出错")
                st.code(result.stderr)
                return False
        except Exception as e:
            st.error(f"启动失败: {e}")
            return False


def run_background_process(script_name, success_msg):
    """启动后台进程 (pythonw)"""
    try:
        python_dir = os.path.dirname(sys.executable)
        pythonw_exe = os.path.join(python_dir, "pythonw.exe")
        if not os.path.exists(pythonw_exe): pythonw_exe = sys.executable

        # 使用 pythonw 启动，无窗口
        CREATE_NO_WINDOW = 0x08000000
        subprocess.Popen([pythonw_exe, script_name], creationflags=CREATE_NO_WINDOW)

        st.toast(success_msg, icon="🚀")
    except Exception as e:
        st.error(f"启动失败: {e}")


def kill_background_processes():
    """
    🛑 核心修改：直接查杀 pythonw.exe
    这会停止所有后台雷达和自动调度器，但不会关掉当前的 WebUI (python.exe)
    """
    try:
        # /F 强制 /IM 镜像名称 /T 终止子进程
        cmd = "taskkill /F /IM pythonw.exe /T"
        subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        st.toast("✅ 已强制清理所有后台雷达/调度进程！", icon="🛑")
    except Exception as e:
        st.error(f"停止失败: {e}")


# ==========================================
# 📊 数据加载区 (保持不变)
# ==========================================
def load_latest_result():
    files = [f for f in os.listdir('.') if f.startswith('N_Rebound_Result') and f.endswith('.csv')]
    if not files: return None
    files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
    return files[0]


def get_realtime_quotes(code_list):
    sina_codes = []
    code_map = {}
    for c in code_list:
        prefix = 'sh' if c.startswith('6') else 'sz'
        sc = f"{prefix}{c}"
        sina_codes.append(sc)
        code_map[sc] = c

    chunk_size = 80
    result_data = []
    proxies = {"http": f"http://127.0.0.1:{PROXY_PORT}", "https": f"http://127.0.0.1:{PROXY_PORT}"}

    for i in range(0, len(sina_codes), chunk_size):
        chunk = sina_codes[i:i + chunk_size]
        url = f"http://hq.sinajs.cn/list={','.join(chunk)}"
        try:
            resp = requests.get(url, proxies=proxies, timeout=3)
            lines = resp.text.strip().split('\n')
            for line in lines:
                if '="' not in line: continue
                s_code = line.split('=')[0].split('_')[-1]
                content = line.split('="')[1].strip('";')
                if not content: continue
                fields = content.split(',')
                if len(fields) < 4: continue
                pure_code = code_map.get(s_code, s_code[2:])
                pct = (float(fields[3]) - float(fields[2])) / float(fields[2]) * 100 if float(fields[2]) > 0 else 0
                result_data.append({
                    '代码': pure_code, '名称': fields[0], '当前价': float(fields[3]), '实时涨幅%': round(pct, 2)
                })
        except:
            pass
    return pd.DataFrame(result_data)


# ==========================================
# 🖥️ UI 布局
# ==========================================

with st.sidebar:
    st.header("🎮 操作台")

    with st.expander("🤖 自动化 (懒人模式)", expanded=True):
        st.info("开启后，每天 16:00 自动运行选股。")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("▶ 开启自动"):
                run_background_process("auto_runner.py", "自动调度已开启")
        with c2:
            # 停止按钮现在直接杀进程
            if st.button("⏹ 关闭所有"):
                kill_background_processes()

        if st.button("📄 查看日志"):
            if os.path.exists("scheduler.log"):
                with open("scheduler.log", "r", encoding="utf-8") as f:
                    st.text_area("Log", f.read(), height=150)

    st.markdown("---")

    st.markdown("### 手动任务")
    if st.button("🚀 立即运行选股"):
        if run_screener():
            time.sleep(1)
            st.rerun()

    st.markdown("### 盘中监控")
    c3, c4 = st.columns(2)
    with c3:
        if st.button("🛡️ 开启雷达"):
            run_background_process("day_radar.py", "雷达已启动")
    with c4:
        # 这里也复用杀进程逻辑
        if st.button("🛑 停止雷达"):
            kill_background_processes()

    st.markdown("---")
    st.caption(f"环境: {sys.executable}")

st.title("🦅 N-Rebound 猎手指挥中心")

csv_file = load_latest_result()

if csv_file:
    df_base = pd.read_csv(csv_file)
    df_base['代码'] = df_base['代码'].astype(str).str.zfill(6)

    with st.container():
        col_title, col_btn = st.columns([4, 1])
        col_title.subheader(f"📊 观察池: {csv_file} (共 {len(df_base)} 只)")
        if col_btn.button("🔄 刷新实时行情"):
            st.rerun()

        all_codes = df_base['代码'].tolist()
        df_real = get_realtime_quotes(all_codes)

        if not df_real.empty:
            df_merge = pd.merge(df_base[['代码', '名称', '回调幅度%', '涨停日期']],
                                df_real[['代码', '当前价', '实时涨幅%']],
                                on=['代码', '名称'], how='left')


            def highlight_surge(val):
                if val > 5.0:
                    return 'background-color: #ff9999; color: black;'
                elif val > 3.0:
                    return 'background-color: #ffe5e5; color: black;'
                return ''


            st.dataframe(
                df_merge.sort_values(by='实时涨幅%', ascending=False).style.map(highlight_surge, subset=['实时涨幅%']),
                height=250, hide_index=True, use_container_width=True
            )
        else:
            st.warning("⚠️ 实时行情加载失败")

    st.divider()

    st.subheader("📈 深度分析")
    cols = st.columns([1, 3])

    with cols[0]:
        stock_options = df_base.apply(lambda x: f"{x['名称']} ({x['代码']})", axis=1)
        selected_opt = st.radio("选择股票:", stock_options, label_visibility="collapsed")

        selected_code = selected_opt.split(" (")[1][:-1]
        selected_name = selected_opt.split(" (")[0]

        row = df_base[df_base['代码'] == selected_code].iloc[0]
        st.info(f"**{selected_name}**\n\n回调深度: {row['回调幅度%']}%\n\n上次涨停: {row['涨停日期']}")

    with cols[1]:
        try:
            sina_symbol = f"sh{selected_code}" if selected_code.startswith('6') else f"sz{selected_code}"
            chart_df = ak.stock_zh_a_daily(symbol=sina_symbol, adjust="qfq")

            if not chart_df.empty:
                chart_df['date'] = pd.to_datetime(chart_df['date'])
                cutoff = datetime.now() - timedelta(days=60)
                chart_df = chart_df[chart_df['date'] > cutoff]

                fig = go.Figure(data=[go.Candlestick(x=chart_df['date'],
                                                     open=chart_df['open'], high=chart_df['high'],
                                                     low=chart_df['low'], close=chart_df['close'])])
                fig.update_layout(xaxis_rangeslider_visible=False, height=500, margin=dict(l=20, r=20, t=20, b=20))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("暂无数据")
        except Exception as e:
            st.error(f"图表错误: {e}")
else:
    st.warning("👋 欢迎！请先点击【立即运行选股】。")